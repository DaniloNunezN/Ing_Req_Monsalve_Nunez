import { useState } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from "recharts";
import {
  BookOpen, LayoutDashboard, Search, Bell, Moon, LogOut,
  BookMarked, History, Calendar, Users, Package, RefreshCw,
  BarChart2, Settings, AlertTriangle, CheckCircle,
  Clock, Eye, EyeOff, Plus, Download, Filter, LayoutGrid, List,
  Pencil, Trash2, ChevronDown, Info, UserX,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | "login" | "dashboard" | "catalogo" | "reservas" | "historial"
  | "notificaciones" | "inventario" | "prestamos" | "devoluciones"
  | "reportes" | "usuarios";

interface AppUser {
  id: string;
  name: string;
  initials: string;
  role: string;
  email: string;
  color: string;
  isAdmin: boolean;
}

// ─── Static Data ──────────────────────────────────────────────────────────────

const DEMO_USERS: AppUser[] = [
  { id: "ana", name: "Ana García", initials: "AG", role: "Estudiante", email: "ana.garcia@unilib.edu", color: "#e67e22", isAdmin: false },
  { id: "carlos", name: "Carlos Mendoza", initials: "CM", role: "Docente", email: "carlos.mendoza@unilib.edu", color: "#8e44ad", isAdmin: false },
  { id: "maria", name: "María López", initials: "ML", role: "Bibliotecario", email: "maria.lopez@unilib.edu", color: "#27ae60", isAdmin: true },
  { id: "pedro", name: "Pedro Soto", initials: "PS", role: "Editor", email: "pedro.soto@unilib.edu", color: "#2980b9", isAdmin: true },
  { id: "laura", name: "Laura Ramírez", initials: "LR", role: "Administrador", email: "laura.ramirez@unilib.edu", color: "#16a085", isAdmin: true },
  { id: "jorge", name: "Jorge Vargas", initials: "JV", role: "Superadmin", email: "jorge.vargas@unilib.edu", color: "#c0392b", isAdmin: true },
];

const BOOKS = [
  { id: "INF-001", isbn: "978-0-13-468599-1", title: "El arte de escribir código limpio", author: "Robert C. Martín", subject: "Informática", location: "Estante A-12", copies: "2/3", status: "disponible", cover: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=200&h=280&fit=crop&auto=format" },
  { id: "INF-002", isbn: "978-0-59-651798-3", title: "Introducción a los Algoritmos", author: "Thomas H. Cormen", subject: "Informática", location: "Estante A-05", copies: "0/5", status: "prestado", cover: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=200&h=280&fit=crop&auto=format" },
  { id: "DER-001", isbn: "978-84-9835-264-5", title: "Derecho Constitucional Chileno", author: "José Luis Cea Egaña", subject: "Derecho", location: "Estante C-03", copies: "3/4", status: "disponible", cover: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=200&h=280&fit=crop&auto=format" },
  { id: "MAT-001", isbn: "978-0-07-340743-7", title: "Cálculo: Trascendentes Tempranas", author: "James Stewart", subject: "Matemáticas", location: "Estante B-08", copies: "0/8", status: "reservado", cover: "https://images.unsplash.com/photo-1635372722656-389f87a941db?w=200&h=280&fit=crop&auto=format" },
  { id: "PSI-001", isbn: "978-84-291-3443-6", title: "Psicología del Desarrollo Humano", author: "Diane E. Papalia", subject: "Psicología", location: "Estante D-15", copies: "4/6", status: "disponible", cover: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=280&fit=crop&auto=format" },
  { id: "ADM-001", isbn: "978-84-7978-312-8", title: "Principios de Administración", author: "Harold Koontz", subject: "Administración", location: "Estante E-02", copies: "3/5", status: "disponible", cover: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=200&h=280&fit=crop&auto=format" },
  { id: "QUI-001", isbn: "978-84-291-1233-4", title: "Química General", author: "Linus Pauling", subject: "Química", location: "Estante F-07", copies: "1/4", status: "prestado", cover: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=200&h=280&fit=crop&auto=format" },
  { id: "HIS-001", isbn: "978-956-10-1234-5", title: "Historia de Chile Contemporáneo", author: "Mario Góngora", subject: "Historia", location: "Estante G-03", copies: "2/3", status: "disponible", cover: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=200&h=280&fit=crop&auto=format" },
  { id: "ECO-001", isbn: "978-84-481-7892-1", title: "Macroeconomía", author: "Diego Morales", subject: "Economía", location: "Estante H-05", copies: "1/3", status: "reservado", cover: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=200&h=280&fit=crop&auto=format" },
  { id: "MAT-002", isbn: "978-0-07-128349-0", title: "Álgebra Lineal y sus Aplicaciones", author: "David C. Lay", subject: "Matemáticas", location: "Estante B-12", copies: "2/4", status: "disponible", cover: "https://images.unsplash.com/photo-1509228468518-180dd4864904?w=200&h=280&fit=crop&auto=format" },
];

const LOANS = [
  { id: "PRES-2026-001", book: "Introducción a los Algoritmos", user: "Ana García", loanDate: "2026-06-01", dueDate: "2026-06-15", status: "atrasado" },
  { id: "PRES-2026-002", book: "Química General", user: "Carlos Mendoza", loanDate: "2026-06-08", dueDate: "2026-06-22", status: "prestado" },
  { id: "PRES-2026-003", book: "El arte de escribir código limpio", user: "Diego Morales", loanDate: "2026-06-10", dueDate: "2026-06-24", status: "prestado" },
  { id: "PRES-2026-004", book: "Derecho Constitucional Chileno", user: "Ana García", loanDate: "2026-05-15", dueDate: "2026-05-29", status: "devuelto" },
  { id: "PRES-2026-005", book: "Psicología del Desarrollo Humano", user: "Sofía Herrera", loanDate: "2026-05-20", dueDate: "2026-06-03", status: "atrasado" },
  { id: "PRES-2026-006", book: "Historia de Chile Contemporáneo", user: "Ana García", loanDate: "2026-06-05", dueDate: "2026-06-19", status: "prestado" },
];

const RESERVATIONS = [
  { id: "RES-001", book: "Cálculo: Trascendentes Tempranas", user: "Ana García", reserveDate: "2026-06-18", expiry: "2026-06-19", status: "activo", timeLeft: "19h", urgent: false },
  { id: "RES-002", book: "Macroeconomía", user: "Diego Morales", reserveDate: "2026-06-15", expiry: "2026-06-16", status: "activo", timeLeft: "6h", urgent: true },
  { id: "RES-003", book: "Introducción a los Algoritmos", user: "Carlos Mendoza", reserveDate: "2026-06-10", expiry: "2026-06-11", status: "expirado", timeLeft: "", urgent: false },
  { id: "RES-004", book: "El Lenguaje de Programación C", user: "Ana García", reserveDate: "2026-06-01", expiry: "2026-06-02", status: "completado", timeLeft: "", urgent: false },
];

const MONTHLY_DATA = [
  { mes: "Ene", prestamos: 180, devoluciones: 165 },
  { mes: "Feb", prestamos: 220, devoluciones: 200 },
  { mes: "Mar", prestamos: 310, devoluciones: 290 },
  { mes: "Abr", prestamos: 280, devoluciones: 265 },
  { mes: "May", prestamos: 350, devoluciones: 320 },
  { mes: "Jun", prestamos: 210, devoluciones: 190 },
];

const CATALOG_DIST = [
  { name: "Disponibles", value: 8, color: "#10b981" },
  { name: "Prestados", value: 3, color: "#f59e0b" },
  { name: "Reservados", value: 2, color: "#3b82f6" },
  { name: "Atrasados", value: 1, color: "#ef4444" },
];

const STUDENT_NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "catalogo", label: "Catálogo", icon: BookOpen },
  { id: "reservas", label: "Reservas", icon: Calendar },
  { id: "historial", label: "Historial", icon: History },
  { id: "notificaciones", label: "Notificaciones", icon: Bell, badge: 4 },
];

const ADMIN_NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "catalogo", label: "Catálogo", icon: BookOpen },
  { id: "inventario", label: "Inventario", icon: Package },
  { id: "prestamos", label: "Préstamos", icon: BookMarked },
  { id: "devoluciones", label: "Devoluciones", icon: RefreshCw },
  { id: "reservas", label: "Reservas", icon: Calendar },
  { id: "historial", label: "Historial", icon: History },
  { id: "usuarios", label: "Usuarios", icon: Users },
  { id: "reportes", label: "Reportes", icon: BarChart2 },
  { id: "notificaciones", label: "Notificaciones", icon: Bell },
  { id: "configuracion", label: "Configuración", icon: Settings },
];

// ─── Shared Components ────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    disponible: "bg-emerald-50 text-emerald-700 border-emerald-200",
    prestado: "bg-amber-50 text-amber-700 border-amber-200",
    reservado: "bg-blue-50 text-blue-700 border-blue-200",
    atrasado: "bg-red-50 text-red-700 border-red-200",
    devuelto: "bg-gray-50 text-gray-500 border-gray-200",
    activo: "bg-emerald-50 text-emerald-700 border-emerald-200",
    expirado: "bg-orange-50 text-orange-700 border-orange-200",
    completado: "bg-indigo-50 text-indigo-700 border-indigo-200",
    cancelado: "bg-gray-50 text-gray-500 border-gray-200",
  };
  const cls = map[status.toLowerCase()] ?? "bg-gray-50 text-gray-500 border-gray-200";
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium border ${cls} capitalize`}>
      {status}
    </span>
  );
}

function Avatar({ user, size = "sm" }: { user: AppUser; size?: "sm" | "md" | "lg" }) {
  const sizes = { sm: "w-7 h-7 text-[11px]", md: "w-8 h-8 text-xs", lg: "w-9 h-9 text-xs" };
  return (
    <div
      className={`${sizes[size]} rounded-full flex items-center justify-center font-bold text-white flex-shrink-0`}
      style={{ backgroundColor: user.color }}
    >
      {user.initials}
    </div>
  );
}

function Sidebar({ user, currentScreen, onNavigate, onLogout }: {
  user: AppUser;
  currentScreen: Screen;
  onNavigate: (s: Screen) => void;
  onLogout: () => void;
}) {
  const nav = user.isAdmin ? ADMIN_NAV : STUDENT_NAV;
  return (
    <aside className="w-52 flex-shrink-0 flex flex-col h-full" style={{ backgroundColor: "#1a3462", fontFamily: "Inter, sans-serif" }}>
      <div className="px-4 py-3.5 flex items-center gap-2.5 border-b border-white/10">
        <div className="w-7 h-7 rounded bg-white/20 flex items-center justify-center flex-shrink-0">
          <BookOpen size={14} className="text-white" />
        </div>
        <div>
          <div className="text-white font-bold text-sm leading-tight tracking-wide">UNILIB</div>
          <div className="text-white/45 text-[10px] leading-tight">Biblioteca Universitaria</div>
        </div>
      </div>

      <nav className="flex-1 py-2 overflow-y-auto">
        {nav.map(({ id, label, icon: Icon, badge }) => {
          const active = currentScreen === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id as Screen)}
              className={`w-full flex items-center gap-2.5 px-4 py-2 text-[13px] transition-colors relative ${
                active
                  ? "bg-white/15 text-white font-medium"
                  : "text-white/55 hover:bg-white/8 hover:text-white/85"
              }`}
            >
              {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-r bg-blue-300" />}
              <Icon size={14} />
              <span className="flex-1 text-left">{label}</span>
              {badge && !active && (
                <span className="bg-red-500 text-white text-[9px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
                  {badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-white/10 p-3">
        <div className="flex items-center gap-2 mb-2">
          <Avatar user={user} size="sm" />
          <div className="flex-1 min-w-0">
            <div className="text-white text-[12px] font-medium truncate">{user.name}</div>
            <div className="text-white/45 text-[10px] capitalize">{user.role}</div>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2 text-white/45 hover:text-white/75 text-[11px] py-1 transition-colors"
        >
          <LogOut size={11} />
          Cerrar sesión
        </button>
      </div>
    </aside>
  );
}

function TopBar({ user }: { user: AppUser }) {
  return (
    <header className="h-11 bg-white border-b border-gray-200/80 flex items-center px-4 gap-3 flex-shrink-0">
      <div className="flex-1 relative">
        <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          className="w-full max-w-xs bg-gray-50 border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-[12px] text-gray-700 placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
          placeholder="Buscar libros, autores, ISBN..."
        />
      </div>
      <button className="text-gray-400 hover:text-gray-600 transition-colors p-1">
        <Moon size={15} />
      </button>
      <button className="relative text-gray-400 hover:text-gray-600 transition-colors p-1">
        <Bell size={15} />
        <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-red-500 rounded-full text-[8px] text-white flex items-center justify-center font-bold">4</span>
      </button>
      <div className="flex items-center gap-1.5 cursor-pointer hover:bg-gray-50 rounded-lg px-2 py-1 transition-colors">
        <Avatar user={user} size="sm" />
        <span className="text-[12px] text-gray-700 font-medium">{user.name.split(" ")[0]}</span>
        <ChevronDown size={11} className="text-gray-400" />
      </div>
    </header>
  );
}

// ─── Dashboard Screen ─────────────────────────────────────────────────────────

function DashboardScreen({ user, onNavigate }: { user: AppUser; onNavigate: (s: Screen) => void }) {
  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="max-w-4xl">
        <div className="mb-1">
          <h1 className="text-[17px] font-semibold text-gray-900">Bienvenido, {user.name.split(" ")[0]} 👋</h1>
          <p className="text-[12px] text-gray-500">jueves, 25 de junio de 2026</p>
        </div>

        <div className="mt-3 mb-4 flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-[12px] text-amber-800">
          <AlertTriangle size={13} className="text-amber-500 flex-shrink-0" />
          <span>⚠ 2 <strong>préstamo(s) atrasado(s)</strong> requieren atención. Tienes <strong>4 notificación(es) sin leer.</strong></span>
          <button className="ml-auto text-amber-600 hover:text-amber-800 font-medium whitespace-nowrap">Ver →</button>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { icon: BookOpen, label: "Libros disponibles", value: "8", color: "text-blue-600", bg: "bg-blue-50" },
            { icon: Clock, label: "Mis préstamos", value: "2", color: "text-amber-600", bg: "bg-amber-50" },
            { icon: Calendar, label: "Mis reservas", value: "2", color: "text-emerald-600", bg: "bg-emerald-50" },
          ].map(({ icon: Icon, label, value, color, bg }) => (
            <div key={label} className="bg-white rounded-lg border border-gray-100 p-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-7 h-7 rounded-lg ${bg} flex items-center justify-center`}>
                  <Icon size={14} className={color} />
                </div>
                <ChevronDown size={12} className="text-gray-300 -rotate-90" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{value}</div>
              <div className="text-[11px] text-gray-500 mt-0.5">{label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-lg border border-gray-100 shadow-sm">
            <div className="px-4 py-3 border-b border-gray-50 flex items-center justify-between">
              <h3 className="text-[13px] font-semibold text-gray-800">Préstamos recientes</h3>
              <button onClick={() => onNavigate("historial")} className="text-[11px] text-blue-600 hover:text-blue-800">
                Ver todos →
              </button>
            </div>
            <div className="divide-y divide-gray-50">
              {LOANS.slice(0, 3).map(loan => (
                <div key={loan.id} className="px-4 py-2.5 flex items-center gap-3">
                  <div className={`w-6 h-6 rounded flex items-center justify-center flex-shrink-0 ${
                    loan.status === "atrasado" ? "bg-red-100" : "bg-blue-50"
                  }`}>
                    <BookOpen size={11} className={loan.status === "atrasado" ? "text-red-500" : "text-blue-500"} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[12px] font-medium text-gray-800 truncate">{loan.book}</div>
                    <div className="text-[10px] text-gray-400">{loan.user} · Vence: {loan.dueDate}</div>
                  </div>
                  <StatusBadge status={loan.status} />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-100 shadow-sm">
            <div className="px-4 py-3 border-b border-gray-50 flex items-center justify-between">
              <h3 className="text-[13px] font-semibold text-gray-800">Reservas activas</h3>
              <button onClick={() => onNavigate("reservas")} className="text-[11px] text-blue-600 hover:text-blue-800">
                Ver todas →
              </button>
            </div>
            <div className="divide-y divide-gray-50">
              {RESERVATIONS.filter(r => r.status === "activo").map((res, i) => (
                <div key={res.id} className="px-4 py-2.5 flex items-center gap-3">
                  <div className="w-8 h-10 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                    <img src={BOOKS[i + 3]?.cover} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[12px] font-medium text-gray-800 truncate">{res.book}</div>
                    <div className="text-[10px] text-gray-400">{res.user}</div>
                  </div>
                  <div className="text-right">
                    <div className={`text-[13px] font-bold ${res.urgent ? "text-red-500" : "text-blue-600"}`}>{res.timeLeft}</div>
                    <div className="text-[10px] text-gray-400">restantes</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Catálogo Screen ──────────────────────────────────────────────────────────

function CatalogoScreen() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [materiaFilter, setMateriaFilter] = useState("");

  const materias = [...new Set(BOOKS.map(b => b.subject))];
  const filtered = BOOKS.filter(b => {
    const q = search.toLowerCase();
    if (q && !b.title.toLowerCase().includes(q) && !b.author.toLowerCase().includes(q)) return false;
    if (statusFilter && b.status !== statusFilter) return false;
    if (materiaFilter && b.subject !== materiaFilter) return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-hidden flex">
      <div className="w-44 flex-shrink-0 border-r border-gray-100 bg-white p-4 overflow-y-auto">
        <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Filtros</h3>

        <div className="mb-4">
          <h4 className="text-[11px] font-semibold text-gray-600 mb-2">Estado</h4>
          {["disponible", "prestado", "reservado"].map(s => (
            <label key={s} className="flex items-center gap-2 mb-1.5 cursor-pointer group">
              <input
                type="radio"
                name="status"
                checked={statusFilter === s}
                onChange={() => setStatusFilter(statusFilter === s ? "" : s)}
                className="w-3 h-3 accent-blue-600"
              />
              <span className="text-[12px] text-gray-600 capitalize group-hover:text-gray-900 transition-colors">
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </span>
            </label>
          ))}
        </div>

        <div className="mb-4">
          <h4 className="text-[11px] font-semibold text-gray-600 mb-2">Materia</h4>
          {materias.map(m => (
            <label key={m} className="flex items-center gap-2 mb-1.5 cursor-pointer group">
              <input
                type="radio"
                name="materia"
                checked={materiaFilter === m}
                onChange={() => setMateriaFilter(materiaFilter === m ? "" : m)}
                className="w-3 h-3 accent-blue-600"
              />
              <span className="text-[12px] text-gray-600 group-hover:text-gray-900 transition-colors">{m}</span>
            </label>
          ))}
        </div>

        <div className="mb-4">
          <h4 className="text-[11px] font-semibold text-gray-600 mb-2">Categoría</h4>
          {["Programación", "Algoritmos", "Derecho Público", "Cálculo"].map(c => (
            <label key={c} className="flex items-center gap-2 mb-1.5 cursor-pointer group">
              <input type="radio" name="cat" className="w-3 h-3 accent-blue-600" />
              <span className="text-[12px] text-gray-600 group-hover:text-gray-900 transition-colors">{c}</span>
            </label>
          ))}
        </div>

        {(statusFilter || materiaFilter) && (
          <button
            onClick={() => { setStatusFilter(""); setMateriaFilter(""); }}
            className="text-[11px] text-blue-600 hover:text-blue-800 transition-colors"
          >
            Limpiar filtros
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="flex-1 relative">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-[12px] placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              placeholder="Buscar por título, autor o ISBN..."
            />
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-[12px] text-gray-600 bg-white hover:bg-gray-50 transition-colors">
            <Filter size={12} />Filtros
          </button>
          <div className="flex border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-1.5 transition-colors ${viewMode === "grid" ? "bg-blue-600 text-white" : "bg-white text-gray-400 hover:bg-gray-50"}`}
            >
              <LayoutGrid size={14} />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-1.5 transition-colors ${viewMode === "list" ? "bg-blue-600 text-white" : "bg-white text-gray-400 hover:bg-gray-50"}`}
            >
              <List size={14} />
            </button>
          </div>
        </div>

        <p className="text-[12px] text-gray-500 mb-3">{filtered.length} resultados</p>

        {viewMode === "grid" ? (
          <div className="grid grid-cols-5 gap-3">
            {filtered.map(book => (
              <div key={book.id} className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="relative">
                  <img src={book.cover} alt={book.title} className="w-full h-28 object-cover bg-gray-100" />
                  <div className="absolute top-1.5 right-1.5">
                    <StatusBadge status={book.status} />
                  </div>
                </div>
                <div className="p-2.5">
                  <div className="text-[11px] font-semibold text-gray-900 leading-tight line-clamp-2 mb-0.5">{book.title}</div>
                  <div className="text-[10px] text-gray-500 mb-1">{book.author}</div>
                  <div className="text-[10px] text-gray-400 mb-2">@ {book.location}</div>
                  <button className="w-full py-1 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-medium rounded transition-colors">
                    Reservar
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="border-b border-gray-100 text-gray-500 font-medium text-left">
                  <th className="px-4 py-2.5">Título</th>
                  <th className="px-4 py-2.5">Autor</th>
                  <th className="px-4 py-2.5">Materia</th>
                  <th className="px-4 py-2.5">Ubicación</th>
                  <th className="px-4 py-2.5">Estado</th>
                  <th className="px-4 py-2.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map(book => (
                  <tr key={book.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <img src={book.cover} alt="" className="w-5 h-7 object-cover rounded flex-shrink-0 bg-gray-100" />
                        <span className="font-medium text-gray-800">{book.title}</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-gray-600">{book.author}</td>
                    <td className="px-4 py-2.5 text-gray-600">{book.subject}</td>
                    <td className="px-4 py-2.5 text-gray-500">{book.location}</td>
                    <td className="px-4 py-2.5"><StatusBadge status={book.status} /></td>
                    <td className="px-4 py-2.5">
                      <button className="px-3 py-1 bg-blue-600 text-white rounded text-[11px] hover:bg-blue-700 transition-colors">
                        Reservar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Reservas Screen ──────────────────────────────────────────────────────────

function ReservasScreen() {
  const [tab, setTab] = useState("Todas");
  const tabs = ["Todas", "Activa", "Expirada", "Completada", "Cancelada"];
  const filtered = RESERVATIONS.filter(r =>
    tab === "Todas" || r.status.toLowerCase() === tab.toLowerCase()
  );

  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="max-w-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-[17px] font-semibold text-gray-900">Reservas</h1>
            <p className="text-[12px] text-gray-500">2 activas</p>
          </div>
          <button className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white text-[12px] font-medium rounded-lg hover:bg-blue-700 transition-colors">
            <Calendar size={13} />Nueva reserva
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-5">
          {RESERVATIONS.filter(r => r.status === "activo").map(res => (
            <div key={res.id} className={`bg-white rounded-lg border p-3 shadow-sm ${res.urgent ? "border-red-200" : "border-gray-100"}`}>
              <div className="flex items-center gap-2 mb-2.5">
                <div className="w-9 h-11 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                  <img src={BOOKS[3].cover} alt="" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="text-[12px] font-semibold text-gray-900">{res.book}</div>
                  <div className="text-[10px] text-gray-500">{res.user}</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className={`flex items-center gap-1 text-[12px] font-medium ${res.urgent ? "text-red-500" : "text-blue-600"}`}>
                  <Clock size={11} />{res.timeLeft} restantes
                </span>
                <button className="text-[11px] text-gray-500 hover:text-red-600 transition-colors border border-gray-200 rounded px-2 py-0.5">
                  Cancelar
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg border border-gray-100 shadow-sm">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-3">
            <div className="relative max-w-xs">
              <Search size={11} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input className="bg-gray-50 border border-gray-200 rounded pl-8 pr-3 py-1.5 text-[12px] placeholder-gray-400 focus:outline-none w-48" placeholder="Buscar..." />
            </div>
            <div className="flex gap-1 ml-auto">
              {tabs.map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                    tab === t ? "bg-blue-600 text-white" : "text-gray-500 hover:bg-gray-100"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <table className="w-full text-[12px]">
            <thead>
              <tr className="border-b border-gray-50 text-gray-500 font-medium text-left">
                <th className="px-4 py-2.5">Libro</th>
                <th className="px-4 py-2.5">Usuario</th>
                <th className="px-4 py-2.5">Fecha reserva</th>
                <th className="px-4 py-2.5">Expiración</th>
                <th className="px-4 py-2.5">Estado</th>
                <th className="px-4 py-2.5">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map(res => (
                <tr key={res.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-2.5 font-medium text-gray-800">{res.book}</td>
                  <td className="px-4 py-2.5 text-gray-600">{res.user}</td>
                  <td className="px-4 py-2.5 text-gray-600">{res.reserveDate}</td>
                  <td className="px-4 py-2.5 text-gray-600">{res.expiry}</td>
                  <td className="px-4 py-2.5"><StatusBadge status={res.status} /></td>
                  <td className="px-4 py-2.5">
                    {res.status === "activo" && (
                      <button className="text-[11px] text-red-600 hover:text-red-800 font-medium transition-colors">Cancelar</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Historial Screen ─────────────────────────────────────────────────────────

function HistorialScreen() {
  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="max-w-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-[17px] font-semibold text-gray-900">Historial de Préstamos</h1>
            <p className="text-[12px] text-gray-500">6 registros</p>
          </div>
          <button className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 bg-white text-gray-700 text-[12px] font-medium rounded-lg hover:bg-gray-50 transition-colors">
            <Download size={13} />Exportar
          </button>
        </div>

        <div className="bg-white rounded-lg border border-gray-100 shadow-sm mb-3 px-4 py-3 flex items-center gap-3 flex-wrap">
          <Filter size={12} className="text-gray-400 flex-shrink-0" />
          <span className="text-[11px] text-gray-500 font-medium">Filtros:</span>
          <select className="text-[11px] border border-gray-200 rounded px-2 py-1 text-gray-600 bg-white focus:outline-none">
            <option>Todos los estados</option>
            <option>Prestado</option>
            <option>Atrasado</option>
            <option>Devuelto</option>
          </select>
          <span className="text-[11px] text-gray-500">Desde</span>
          <input type="text" placeholder="dd-mm-aaaa" className="text-[11px] border border-gray-200 rounded px-2 py-1 text-gray-600 w-28 focus:outline-none" />
          <span className="text-[11px] text-gray-500">Hasta</span>
          <input type="text" placeholder="dd-mm-aaaa" className="text-[11px] border border-gray-200 rounded px-2 py-1 text-gray-600 w-28 focus:outline-none" />
        </div>

        <div className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 font-medium text-left">
                <th className="px-4 py-2.5">Comprobante</th>
                <th className="px-4 py-2.5">Libro</th>
                <th className="px-4 py-2.5">Fecha préstamo</th>
                <th className="px-4 py-2.5">Fecha devolución</th>
                <th className="px-4 py-2.5">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {LOANS.map(loan => (
                <tr key={loan.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-2.5 font-mono text-[10px] text-blue-600 font-medium">{loan.id}</td>
                  <td className="px-4 py-2.5 font-medium text-gray-800">{loan.book}</td>
                  <td className="px-4 py-2.5 text-gray-600">{loan.loanDate}</td>
                  <td className={`px-4 py-2.5 font-medium ${loan.status === "atrasado" ? "text-red-600" : "text-gray-600"}`}>
                    {loan.dueDate}
                  </td>
                  <td className="px-4 py-2.5"><StatusBadge status={loan.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Notificaciones Screen ────────────────────────────────────────────────────

function NotificacionesScreen() {
  const [tab, setTab] = useState("Todas");
  const notifs = [
    { Icon: BookOpen, color: "bg-blue-100 text-blue-600", title: "Devolución próxima", desc: 'El libro "Introducción a los Algoritmos" vence en 2 días.', time: "hace 11 días", unread: false },
    { Icon: Calendar, color: "bg-emerald-100 text-emerald-600", title: "Reserva disponible", desc: 'Tu reserva del libro "Cálculo: Trascendentes Tempranas" está lista para retirar.', time: "hace 10 días", unread: true },
    { Icon: AlertTriangle, color: "bg-amber-100 text-amber-600", title: "Préstamo atrasado", desc: "Tienes un préstamo vencido. Por favor devuelve el material a la brevedad.", time: "hace 12 días", unread: true },
    { Icon: Info, color: "bg-gray-100 text-gray-500", title: "Nuevos materiales disponibles", desc: "Se han agregado 15 nuevos libros al catálogo de Ingeniería.", time: "hace 12 días", unread: false },
  ];
  const shown = tab === "Sin leer" ? notifs.filter(n => n.unread) : notifs;

  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="max-w-2xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-[17px] font-semibold text-gray-900">Notificaciones</h1>
            <p className="text-[12px] text-gray-500">2 sin leer</p>
          </div>
          <button className="text-[12px] text-blue-600 hover:text-blue-800 flex items-center gap-1 transition-colors">
            <CheckCircle size={13} />Marcar todas como leídas
          </button>
        </div>

        <div className="flex gap-1.5 mb-4">
          {["Todas", "Sin leer"].map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded-lg text-[12px] font-medium transition-colors ${
                tab === t
                  ? "bg-blue-600 text-white"
                  : "bg-white text-gray-500 border border-gray-200 hover:bg-gray-50"
              }`}
            >
              {t}{t === "Sin leer" ? " (2)" : ""}
            </button>
          ))}
        </div>

        <div className="space-y-2">
          {shown.map((n, i) => (
            <div key={i} className={`bg-white rounded-lg border border-gray-100 shadow-sm px-4 py-3 flex items-start gap-3 transition-colors hover:bg-gray-50/50 ${n.unread ? "border-l-2 border-l-blue-400" : ""}`}>
              <div className={`w-7 h-7 rounded-full ${n.color} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                <n.Icon size={13} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[12px] font-semibold text-gray-800">{n.title}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">{n.time}</span>
                    {n.unread && <span className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />}
                  </div>
                </div>
                <p className="text-[12px] text-gray-600 leading-relaxed">{n.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Inventario Screen (Admin) ────────────────────────────────────────────────

function InventarioScreen() {
  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-[17px] font-semibold text-gray-900">Inventario de Materiales</h1>
          <p className="text-[12px] text-gray-500">12 materiales registrados</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white text-[12px] font-medium rounded-lg hover:bg-blue-700 transition-colors">
          <Plus size={13} />Nuevo material
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100">
          <div className="relative max-w-sm">
            <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-[12px] placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              placeholder="Buscar por código, ISBN, título o autor..."
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="border-b border-gray-100 text-gray-500 font-medium text-left bg-gray-50/50">
                <th className="px-4 py-2.5 whitespace-nowrap">Código</th>
                <th className="px-4 py-2.5 whitespace-nowrap">ISBN</th>
                <th className="px-4 py-2.5">Título</th>
                <th className="px-4 py-2.5">Autor</th>
                <th className="px-4 py-2.5">Materia</th>
                <th className="px-4 py-2.5 whitespace-nowrap">Ubicación</th>
                <th className="px-4 py-2.5 whitespace-nowrap">Ejem.</th>
                <th className="px-4 py-2.5">Estado</th>
                <th className="px-4 py-2.5">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {BOOKS.map(book => (
                <tr key={book.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-2.5 font-mono text-[10px] text-blue-600 font-medium whitespace-nowrap">{book.id}</td>
                  <td className="px-4 py-2.5 font-mono text-[10px] text-gray-400 whitespace-nowrap">{book.isbn}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <img src={book.cover} alt="" className="w-5 h-7 object-cover rounded flex-shrink-0 bg-gray-100" />
                      <span className="font-medium text-gray-800 truncate max-w-[130px]">{book.title}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-gray-600 whitespace-nowrap">{book.author}</td>
                  <td className="px-4 py-2.5 text-gray-600">{book.subject}</td>
                  <td className="px-4 py-2.5 text-gray-500 whitespace-nowrap">{book.location}</td>
                  <td className="px-4 py-2.5 text-gray-600 text-center">{book.copies}</td>
                  <td className="px-4 py-2.5"><StatusBadge status={book.status} /></td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <button className="text-gray-400 hover:text-blue-600 transition-colors p-0.5"><Pencil size={13} /></button>
                      <button className="text-gray-400 hover:text-red-600 transition-colors p-0.5"><Trash2 size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Préstamos Screen (Admin) ─────────────────────────────────────────────────

function PrestamosScreen() {
  const [tab, setTab] = useState("Todos");
  const tabs = ["Todos", "Prestado", "Atrasado", "Devuelto"];
  const filtered = LOANS.filter(l => tab === "Todos" || l.status === tab.toLowerCase());

  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-[17px] font-semibold text-gray-900">Préstamos</h1>
          <p className="text-[12px] text-gray-500">5 activos · 2 atrasados</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white text-[12px] font-medium rounded-lg hover:bg-blue-700 transition-colors">
          <Plus size={13} />Nuevo préstamo
        </button>
      </div>

      <div className="flex items-center gap-3 mb-4">
        <div className="relative max-w-xs flex-1">
          <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="w-full bg-white border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-[12px] placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
            placeholder="Buscar préstamo..."
          />
        </div>
        <div className="flex gap-1">
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded text-[11px] font-medium transition-colors ${
                tab === t ? "bg-blue-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {filtered.map(loan => (
          <div key={loan.id} className={`bg-white rounded-lg border shadow-sm p-4 hover:shadow-md transition-shadow ${
            loan.status === "atrasado" ? "border-red-200" : "border-gray-100"
          }`}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="text-[13px] font-semibold text-gray-900">{loan.book}</div>
                <div className="text-[11px] text-gray-500 mt-0.5">{loan.user}</div>
              </div>
              <StatusBadge status={loan.status} />
            </div>
            <div className="grid grid-cols-2 gap-2 mb-2">
              <div>
                <div className="text-[10px] text-gray-400 mb-0.5">Fecha préstamo</div>
                <div className="text-[12px] font-medium text-gray-700">{loan.loanDate}</div>
              </div>
              <div>
                <div className="text-[10px] text-gray-400 mb-0.5">Fecha devolución</div>
                <div className={`text-[12px] font-medium ${loan.status === "atrasado" ? "text-red-600" : "text-gray-700"}`}>
                  {loan.dueDate}{loan.status === "atrasado" ? " (1d atrasado)" : ""}
                </div>
              </div>
            </div>
            <div className="font-mono text-[10px] text-gray-400">{loan.id}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Devoluciones Screen (Admin) ──────────────────────────────────────────────

function DevolucionesScreen() {
  const activeLoans = LOANS.filter(l => l.status !== "devuelto");

  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="max-w-2xl">
        <h1 className="text-[17px] font-semibold text-gray-900 mb-0.5">Registro de Devoluciones</h1>
        <p className="text-[12px] text-gray-500 mb-5">5 préstamos activos · 2 atrasados</p>

        <div className="bg-white rounded-lg border border-gray-100 shadow-sm p-4 mb-5">
          <h3 className="text-[13px] font-semibold text-gray-800 mb-3">Buscar préstamo para devolver</h3>
          <div className="flex gap-2">
            <input
              className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-[12px] placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
              placeholder="Número de comprobante, libro o usuario..."
            />
            <button className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-[12px] font-medium rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
              <Search size={12} />Buscar
            </button>
          </div>
          <p className="text-[10px] text-gray-400 mt-1.5">Ejemplos: PRES-2026-001, Algoritmos, Ana García</p>
        </div>

        <h3 className="text-[13px] font-semibold text-gray-800 mb-3">Préstamos activos</h3>
        <div className="space-y-2">
          {activeLoans.map(loan => (
            <div key={loan.id} className="bg-white rounded-lg border border-gray-100 shadow-sm px-4 py-3 flex items-center gap-3 hover:bg-gray-50/50 transition-colors">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                loan.status === "atrasado" ? "bg-red-100" : "bg-blue-50"
              }`}>
                <BookOpen size={13} className={loan.status === "atrasado" ? "text-red-500" : "text-blue-500"} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12px] font-semibold text-gray-800">{loan.book}</div>
                <div className="text-[10px] text-gray-500">{loan.user} · Vence: {loan.dueDate}</div>
              </div>
              <button className={`px-3 py-1.5 text-white text-[11px] font-medium rounded transition-colors ${
                loan.status === "atrasado" ? "bg-red-500 hover:bg-red-600" : "bg-blue-600 hover:bg-blue-700"
              }`}>
                Devolver
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Reportes Screen (Admin) ──────────────────────────────────────────────────

function ReportesScreen() {
  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-[17px] font-semibold text-gray-900">Reportes y Estadísticas</h1>
          <p className="text-[12px] text-gray-500">Resumen del período: Enero – Junio 2026</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 bg-red-50 text-red-700 text-[12px] font-medium rounded-lg hover:bg-red-100 transition-colors">
            <Download size={12} />PDF
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 border border-emerald-200 bg-emerald-50 text-emerald-700 text-[12px] font-medium rounded-lg hover:bg-emerald-100 transition-colors">
            <Download size={12} />Excel
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-5">
        {[
          { label: "Préstamos este mes", value: "156", change: "+12%", icon: BookMarked, color: "text-blue-600", bg: "bg-blue-50", pos: true },
          { label: "Usuarios activos", value: "247", change: "+8%", icon: Users, color: "text-emerald-600", bg: "bg-emerald-50", pos: true },
          { label: "Uso semanal promedio", value: "89%", change: "+3%", icon: BarChart2, color: "text-purple-600", bg: "bg-purple-50", pos: true },
          { label: "Tasa de morosidad", value: "4.2%", change: "-1%", icon: AlertTriangle, color: "text-amber-600", bg: "bg-amber-50", pos: false },
        ].map(({ label, value, change, icon: Icon, color, bg, pos }) => (
          <div key={label} className="bg-white rounded-lg border border-gray-100 shadow-sm p-3.5 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-2">
              <div className={`w-7 h-7 rounded-lg ${bg} flex items-center justify-center`}>
                <Icon size={14} className={color} />
              </div>
              <span className={`text-[10px] font-semibold ${pos ? "text-emerald-600" : "text-red-600"}`}>{change}</span>
            </div>
            <div className="text-[22px] font-bold text-gray-900 leading-tight">{value}</div>
            <div className="text-[11px] text-gray-500 mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-5 gap-4">
        <div className="col-span-3 bg-white rounded-lg border border-gray-100 shadow-sm p-4">
          <h3 className="text-[13px] font-semibold text-gray-800 mb-4">Préstamos vs Devoluciones (mensual)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={MONTHLY_DATA} barCategoryGap="35%" barGap={3}>
              <XAxis dataKey="mes" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e5e7eb", boxShadow: "0 4px 12px rgba(0,0,0,0.08)" }}
                cursor={{ fill: "rgba(0,0,0,0.03)" }}
              />
              <Bar dataKey="prestamos" fill="#3b82f6" radius={[3, 3, 0, 0]} name="Préstamos" />
              <Bar dataKey="devoluciones" fill="#10b981" radius={[3, 3, 0, 0]} name="Devoluciones" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="col-span-2 bg-white rounded-lg border border-gray-100 shadow-sm p-4">
          <h3 className="text-[13px] font-semibold text-gray-800 mb-2">Distribución del catálogo</h3>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie
                data={CATALOG_DIST}
                cx="50%"
                cy="50%"
                innerRadius={44}
                outerRadius={68}
                dataKey="value"
                paddingAngle={2}
              >
                {CATALOG_DIST.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e5e7eb" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-1">
            {CATALOG_DIST.map(d => (
              <div key={d.name} className="flex items-center justify-between text-[12px]">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ backgroundColor: d.color }} />
                  <span className="text-gray-600">{d.name}</span>
                </div>
                <span className="font-semibold text-gray-800">{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Usuarios Screen (Admin) ──────────────────────────────────────────────────

const ALL_USERS_DATA = [
  ...DEMO_USERS,
  { id: "sofia", name: "Sofía Herrera", initials: "SH", role: "Estudiante", email: "sofia.herrera@unilib.edu", color: "#e91e63", isAdmin: false },
  { id: "diego", name: "Diego Morales", initials: "DM", role: "Docente", email: "diego.morales@unilib.edu", color: "#607d8b", isAdmin: false },
];

const RUTS: Record<string, string> = {
  ana: "12.345.678-9", carlos: "15.234.567-K", maria: "15.234.567-K",
  pedro: "11.222.333-4", laura: "8.765.432-1", jorge: "7.654.321-0",
  sofia: "14.567.890-2", diego: "13.456.789-1",
};

function UsuariosScreen() {
  return (
    <div className="flex-1 overflow-y-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-[17px] font-semibold text-gray-900">Gestión de Usuarios</h1>
          <p className="text-[12px] text-gray-500">6 usuarios registrados</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white text-[12px] font-medium rounded-lg hover:bg-blue-700 transition-colors">
          <Plus size={13} />Nuevo usuario
        </button>
      </div>

      <div className="mb-4 relative max-w-sm">
        <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          className="w-full bg-white border border-gray-200 rounded-lg pl-8 pr-3 py-2 text-[12px] placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
          placeholder="Buscar por nombre, correo o RUT..."
        />
      </div>

      <div className="grid grid-cols-3 gap-3">
        {ALL_USERS_DATA.slice(0, 6).map(u => (
          <div key={u.id} className="bg-white rounded-lg border border-gray-100 shadow-sm p-4 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-3 mb-3">
              <Avatar user={u} size="lg" />
              <div className="flex-1 min-w-0">
                <div className="text-[13px] font-semibold text-gray-900">{u.name}</div>
                <div className="text-[10px] text-gray-500 truncate">{u.email}</div>
                <span
                  className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-medium text-white"
                  style={{ backgroundColor: u.color }}
                >
                  {u.role}
                </span>
              </div>
            </div>
            <div className="text-[10px] text-gray-500 mb-1">RUT: {RUTS[u.id] ?? "—"}</div>
            <div className="flex items-center gap-3 text-[11px] text-gray-600 mb-3">
              <span>Préstamos: <strong>2</strong></span>
              <span>Multas: <strong>0</strong></span>
            </div>
            <div className="flex items-center gap-1.5">
              <button className="flex-1 flex items-center justify-center gap-1 px-2 py-1.5 border border-gray-200 rounded text-[11px] text-gray-600 hover:bg-gray-50 transition-colors">
                <Pencil size={10} />Editar
              </button>
              <button className="flex-1 flex items-center justify-center gap-1 px-2 py-1.5 border border-amber-200 bg-amber-50 rounded text-[11px] text-amber-700 hover:bg-amber-100 transition-colors">
                <UserX size={10} />Bloquear
              </button>
              <button className="flex items-center justify-center p-1.5 border border-red-200 bg-red-50 rounded text-red-600 hover:bg-red-100 transition-colors">
                <Trash2 size={12} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Login Screen ─────────────────────────────────────────────────────────────

function LoginScreen({ onLogin }: { onLogin: (user: AppUser) => void }) {
  const [showPass, setShowPass] = useState(false);
  const [email, setEmail] = useState("nombre@unilib.edu");

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "Inter, sans-serif" }}>
      <div
        className="w-5/12 flex-shrink-0 relative overflow-hidden flex flex-col justify-between p-10"
        style={{ backgroundColor: "#1a3462" }}
      >
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute w-72 h-72 rounded-full -top-12 -left-20 opacity-10" style={{ backgroundColor: "#3b82f6" }} />
          <div className="absolute w-56 h-56 rounded-full top-36 right-0 opacity-8" style={{ backgroundColor: "#60a5fa" }} />
          <div className="absolute w-40 h-40 rounded-full bottom-24 left-6 opacity-10" style={{ backgroundColor: "#93c5fd" }} />
        </div>
        <div className="relative">
          <div className="flex items-center gap-2.5 mb-14">
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <BookOpen size={17} className="text-white" />
            </div>
            <span className="text-white font-bold text-base tracking-wide">UNILIB</span>
          </div>
          <h1 className="text-[32px] font-bold text-white leading-tight mb-4">
            Sistema de Gestión<br />de Biblioteca<br />Universitaria
          </h1>
          <p className="text-white/55 text-[14px] leading-relaxed max-w-xs">
            Accede al catálogo, gestiona préstamos, reservas y mucho más desde una sola plataforma moderna e intuitiva.
          </p>
        </div>
        <div className="relative">
          <div className="grid grid-cols-3 gap-6 mb-6">
            {[
              { value: "12,450", label: "Libros" },
              { value: "3,280", label: "Usuarios" },
              { value: "98%", label: "Disponibilidad" },
            ].map(s => (
              <div key={s.label}>
                <div className="text-white font-bold text-xl leading-tight">{s.value}</div>
                <div className="text-white/45 text-[12px]">{s.label}</div>
              </div>
            ))}
          </div>
          <p className="text-white/25 text-[10px]">© 2026 UNILIB · Universidad Nacional</p>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-10 bg-white">
        <div className="w-full max-w-sm">
          <h2 className="text-[26px] font-bold text-gray-900 mb-1">Iniciar sesión</h2>
          <p className="text-[13px] text-blue-600 mb-7">Ingresa con tu correo institucional</p>

          <div className="space-y-4 mb-5">
            <div>
              <label className="block text-[12px] font-semibold text-gray-700 mb-1.5">Correo institucional</label>
              <input
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-[13px] text-gray-700 placeholder-gray-300 focus:outline-none focus:border-blue-400 transition-colors bg-white"
                placeholder="nombre@unilib.edu"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[12px] font-semibold text-gray-700">Contraseña</label>
                <button className="text-[11px] text-blue-600 hover:text-blue-800 transition-colors">
                  ¿Olvidaste tu contraseña?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  defaultValue="123456"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-[13px] pr-10 focus:outline-none focus:border-blue-400 transition-colors"
                />
                <button
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={() => onLogin(DEMO_USERS[0])}
            className="w-full py-2.5 bg-blue-600 text-white text-[13px] font-semibold rounded-lg hover:bg-blue-700 transition-colors mb-5 shadow-sm"
          >
            Ingresar al sistema
          </button>

          <div className="border-t border-gray-100 pt-5">
            <p className="text-[10px] text-center text-gray-400 font-semibold uppercase tracking-widest mb-3">
              Acceso rápido (Demo)
            </p>
            <div className="grid grid-cols-2 gap-2">
              {DEMO_USERS.map(u => (
                <button
                  key={u.id}
                  onClick={() => onLogin(u)}
                  className="flex items-center gap-2 p-2 border border-gray-100 rounded-lg hover:bg-gray-50 hover:border-gray-200 transition-colors text-left"
                >
                  <Avatar user={u} size="sm" />
                  <div>
                    <div className="text-[12px] font-semibold text-gray-800">{u.name.split(" ")[0]}</div>
                    <div className="text-[10px] text-gray-400 capitalize">{u.role.toLowerCase()}</div>
                  </div>
                </button>
              ))}
            </div>
            <p className="text-[10px] text-center text-gray-400 mt-3">
              Contraseña de demo: <strong className="text-gray-600">123456</strong>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── App Layout ───────────────────────────────────────────────────────────────

function AppLayout({ user, onLogout }: { user: AppUser; onLogout: () => void }) {
  const [screen, setScreen] = useState<Screen>("dashboard");

  const renderScreen = () => {
    switch (screen) {
      case "dashboard": return <DashboardScreen user={user} onNavigate={setScreen} />;
      case "catalogo": return <CatalogoScreen />;
      case "reservas": return <ReservasScreen />;
      case "historial": return <HistorialScreen />;
      case "notificaciones": return <NotificacionesScreen />;
      case "inventario": return <InventarioScreen />;
      case "prestamos": return <PrestamosScreen />;
      case "devoluciones": return <DevolucionesScreen />;
      case "reportes": return <ReportesScreen />;
      case "usuarios": return <UsuariosScreen />;
      default: return <DashboardScreen user={user} onNavigate={setScreen} />;
    }
  };

  return (
    <div className="h-screen flex overflow-hidden" style={{ fontFamily: "Inter, sans-serif", backgroundColor: "#f0f3f9" }}>
      <Sidebar user={user} currentScreen={screen} onNavigate={setScreen} onLogout={onLogout} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar user={user} />
        {renderScreen()}
      </div>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);

  if (!currentUser) {
    return <LoginScreen onLogin={setCurrentUser} />;
  }

  return <AppLayout user={currentUser} onLogout={() => setCurrentUser(null)} />;
}
