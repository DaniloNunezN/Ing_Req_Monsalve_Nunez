
  # Mockups basico UNILIB

  This is a code bundle for Mockups basico UNILIB. The original project is available at https://www.figma.com/design/KD0AmEvWcaQCyuTsVOaGRR/Mockups-basico-UNILIB.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  